// app/login.tsx
import { useRouter } from "expo-router";
import React from "react";
import { Controller, useForm } from "react-hook-form";
import {
  Alert,
  Button,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { useAuth } from "../hooks/useAuth";
import api from "./api/client";

export default function LoginScreen() {
  const { control, handleSubmit } = useForm({
    defaultValues: { email: "", password: "" },
  });
  const auth = useAuth();
  const router = useRouter();

  const onSubmit = async (data: any) => {
    try {
      const res = await api.post("/auth/login", data);
      await auth.signIn(res.data.user, res.data.token);
      router.replace("./workflows");
    } catch (err: any) {
      // Mock login for frontend development
      if (!err?.response) {
        await auth.signIn(
          { id: "1", name: "Dev User", email: data.email },
          "mock-token"
        );
        router.replace("./workflows");
        return;
      }
      Alert.alert("Login failed", err?.response?.data?.message ?? err.message);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Sign in</Text>
      <Controller
        name="email"
        control={control}
        render={({ field }) => (
          <TextInput
            style={styles.input}
            placeholder="Email"
            value={field.value}
            onChangeText={field.onChange}
            autoCapitalize="none"
            keyboardType="email-address"
          />
        )}
      />
      <Controller
        name="password"
        control={control}
        render={({ field }) => (
          <TextInput
            style={styles.input}
            placeholder="Password"
            value={field.value}
            onChangeText={field.onChange}
            secureTextEntry
          />
        )}
      />
      <Button title="Login" onPress={handleSubmit(onSubmit)} />
      <TouchableOpacity
        onPress={() => router.replace("./signup")}
        style={{ marginTop: 12 }}
      >
        <Text style={{ color: "#2563eb" }}>New here? Create an account</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, justifyContent: "center" },
  title: { fontSize: 20, marginBottom: 12, textAlign: "center" },
  input: {
    borderWidth: 1,
    borderColor: "#ddd",
    padding: 10,
    marginBottom: 12,
    borderRadius: 6,
  },
});
