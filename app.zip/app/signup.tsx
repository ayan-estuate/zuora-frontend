// app/signup.tsx
import { useRouter } from "expo-router";
import React from "react";
import { Controller, useForm } from "react-hook-form";
import { Alert, Button, StyleSheet, Text, TextInput, TouchableOpacity, View } from "react-native";
import { useAuth } from "../hooks/useAuth";
import api from "./api/client";

export default function SignupScreen() {
  const { control, handleSubmit } = useForm({
    defaultValues: { name: "", email: "", password: "" },
  });
  const auth = useAuth();
  const router = useRouter();

  const onSubmit = async (data: any) => {
    try {
      const res = await api.post("/auth/signup", data);
      await auth.signIn(res.data.user, res.data.token);
      router.replace("./workflows");
    } catch (err: any) {
      // Allow frontend-only dev
      if (!err?.response) {
        await auth.signIn(
          { id: "1", name: data.name || "New User", email: data.email },
          "mock-token"
        );
        router.replace("./workflows");
        return;
      }
      Alert.alert("Signup failed", err?.response?.data?.message ?? err.message);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Create account</Text>
      <Controller
        name="name"
        control={control}
        render={({ field }) => (
          <TextInput
            style={styles.input}
            placeholder="Full name"
            value={field.value}
            onChangeText={field.onChange}
          />
        )}
      />
      <Controller
        name="email"
        control={control}
        render={({ field }) => (
          <TextInput
            style={styles.input}
            placeholder="Email"
            value={field.value}
            onChangeText={field.onChange}
            autoCapitalize="none"
            keyboardType="email-address"
          />
        )}
      />
      <Controller
        name="password"
        control={control}
        render={({ field }) => (
          <TextInput
            style={styles.input}
            placeholder="Password"
            value={field.value}
            onChangeText={field.onChange}
            secureTextEntry
          />
        )}
      />
      <Button title="Sign up" onPress={handleSubmit(onSubmit)} />
      <TouchableOpacity onPress={() => router.replace("./login")}
        style={{ marginTop: 12 }}>
        <Text style={{ color: "#2563eb" }}>Have an account? Sign in</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, justifyContent: "center" },
  title: { fontSize: 20, fontWeight: "600", marginBottom: 12 },
  input: {
    borderWidth: 1,
    borderColor: "#ccc",
    borderRadius: 6,
    padding: 12,
    marginBottom: 12,
  },
});


