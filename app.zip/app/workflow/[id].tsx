// app/workflow/[id].tsx
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useLocalSearchParams, useRouter } from "expo-router";
import React, { useState } from "react";
import { Alert, Button, StyleSheet, Text, TextInput, View } from "react-native";
import api, { handleAPIError } from "../api/client";

export default function WorkflowDetail() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const qc = useQueryClient();
  const router = useRouter();
  const [comment, setComment] = useState("");

  const { data, isError, error } = useQuery({
    queryKey: ["workflow", id],
    queryFn: async () => {
      try {
        return (await api.get(`/workflows/${id}`)).data;
      } catch (err) {
        if (__DEV__) {
          return {
            id,
            workflowName: "Invoice Refund Approval",
            summary: "Refund for INV-10023",
            payload: { invoice: "INV-10023", amount: 120.5, customer: "ACME" },
            requester: "Billing Ops",
            createdAt: new Date().toISOString(),
            status: "pending",
          };
        }
        throw handleAPIError(err);
      }
    },
  });

  // Always call hooks at the top level
  const approve = useMutation({
    mutationFn: (payload: { comment: string }) =>
      api.post(`/workflows/${id}/approve`, payload),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["pendingWorkflows"] });
      Alert.alert("Approved");
      router.back();
    },
  });

  const reject = useMutation({
    mutationFn: (payload: { comment: string }) =>
      api.post(`/workflows/${id}/reject`, payload),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["pendingWorkflows"] });
      Alert.alert("Rejected");
      router.back();
    },
  });

  if (isError) {
    return (
      <View style={{ padding: 16 }}>
        <Text>Error: {(error as Error).message}</Text>
      </View>
    );
  }

  if (!data)
    return (
      <View style={{ padding: 16 }}>
        <Text>Loading...</Text>
      </View>
    );

  return (
    <View style={{ padding: 16 }}>
      <Text style={{ fontSize: 18, fontWeight: "600" }}>
        {data.workflowName}
      </Text>
      <Text style={{ marginTop: 8 }}>{data.summary}</Text>
      <Text style={{ marginTop: 8, color: "#555" }}>
        Payload: {JSON.stringify(data.payload)}
      </Text>

      <TextInput
        style={styles.input}
        placeholder="Optional comment"
        value={comment}
        onChangeText={setComment}
      />
      <View
        style={{
          flexDirection: "row",
          justifyContent: "space-between",
          marginTop: 12,
        }}
      >
        <Button
          title="Approve"
          disabled={approve.isPending}
          onPress={() => approve.mutate({ comment })}
        />
        <Button
          title="Reject"
          disabled={reject.isPending}
          onPress={() => reject.mutate({ comment })}
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  input: {
    marginTop: 12,
    borderWidth: 1,
    borderColor: "#ddd",
    padding: 8,
    borderRadius: 6,
  },
});
