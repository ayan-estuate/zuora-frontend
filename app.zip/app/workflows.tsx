// app/workflows.tsx
import { useQuery } from "@tanstack/react-query";
import { useRouter } from "expo-router";
import React from "react";
import {
  FlatList,
  RefreshControl,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { Workflow } from "../types/workflow";
import api, { handleAPIError } from "./api/client";

async function fetchPending() {
  try {
    const r = await api.get("/workflows/pending");
    return r.data;
  } catch (err) {
    if (__DEV__) {
      return [
        {
          id: "1",
          workflowName: "Invoice Refund Approval",
          summary: "Refund for INV-10023",
          payload: { invoice: "INV-10023", amount: 120.5, customer: "ACME" },
          requester: "Billing Ops",
          createdAt: new Date().toISOString(),
          status: "pending",
        },
      ];
    }
    throw handleAPIError(err);
  }
}

export default function WorkflowsList() {
  const router = useRouter();
  const {
    data = [],
    isLoading,
    refetch,
  } = useQuery<Workflow[]>({
    queryKey: ["pendingWorkflows"],
    queryFn: fetchPending,
  });

  if (isLoading && !data.length) {
    return (
      <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
        <Text>Loading workflows...</Text>
      </View>
    );
  }

  return (
    <View style={{ flex: 1 }}>
      <FlatList
        data={data}
        keyExtractor={(i: Workflow) => i.id}
        refreshControl={
          <RefreshControl refreshing={isLoading} onRefresh={refetch} />
        }
        renderItem={({ item }: { item: Workflow }) => (
          <TouchableOpacity
            onPress={() => router.push(`./workflow/${item.id}`)}
          >
            <View style={styles.item}>
              <Text style={styles.title}>{item.workflowName}</Text>
              <Text style={styles.subtitle}>{item.summary}</Text>
              <Text style={styles.meta}>
                {item.requester} • {new Date(item.createdAt).toLocaleString()}
              </Text>
            </View>
          </TouchableOpacity>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  item: { padding: 16, borderBottomWidth: 1, borderColor: "#eee" },
  title: { fontWeight: "600" },
  subtitle: { marginTop: 4, color: "#555" },
  meta: { marginTop: 6, color: "#999", fontSize: 12 },
});
